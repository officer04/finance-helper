export { Footer } from './footer';
export { Home } from './home';
export { FormRegister } from './form-register';
export { FormAuthorization as FormLogin } from './form-authorization';
export { MenuListComposition } from './menu-list-composition';
export { Header } from './header/header';
export { HeaderBase } from './header/header-base';
export { HeaderAuth } from './header/header-auth';
