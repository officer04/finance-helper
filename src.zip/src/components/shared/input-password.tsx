import React, { useState } from 'react';
import {
  Controller,
  Control,
  FieldValues,
  RegisterOptions,
  Path,
} from 'react-hook-form';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import Visibility from '@mui/icons-material/Visibility';

/**
 * Пропсы для TextField
 */
interface InputPasswordProps<T extends FieldValues> extends BaseInputProps<T> {
  defaultValue?: string;
  style?: React.CSSProperties;
  // onChange, onInput, value, variant, ............
}

/**
 * Пропсы для Select
 */
interface InputSelectProps<T extends FieldValues> extends BaseInputProps<T> {
  items: [];
  // onChange, value, variant, ............ тут повторяются поля, но они будут других типов
}

/**
 * Основной интерфейс пропсов, тут значения, которые есть вообще у всех инпутов в системе
 */
interface BaseInputProps<T extends FieldValues> {
  control: Control<T>;
  name: Path<T>;
  label: string;
  rules?: Omit<
    RegisterOptions<T, Path<T>>,
    'valueAsNumber' | 'valueAsDate' | 'setValueAs' | 'disabled'
  >; // Опциональные правила валидации
  margin?: "dense" | "normal" | "none" | undefined
}

export default function InputPassword<T extends FieldValues>({
  control,
  name,
  label,
  rules,
  style,
  margin
}: InputPasswordProps<T>) {
  const [showPassword, setShowPassword] = useState(false);

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  return (
    <Controller
      name={name}
      control={control}
      rules={rules}
      render={({ field, fieldState }) => (
        <TextField
          style={style}
          {...field}
          type={showPassword ? 'text' : 'password'}
          label={label}
          error={!!fieldState.error}
          helperText={fieldState.error ? fieldState.error.message : ''}
          variant="outlined"
          margin={margin}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  edge="end"
                >
                  {showPassword ? <Visibility /> : <VisibilityOff />}
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
      )}
    />
  );
}
