import React, { FC, useState } from 'react';
import { Controller, Control, FieldValues, RegisterOptions, Path } from 'react-hook-form';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';

export interface SelectItem {
  key: any;
  value: any;
}
/**
 * Пропсы для Select
 */
interface InputSelectProps<T extends FieldValues> extends BaseInputProps<T> {
  items: SelectItem[];
  style?: React.CSSProperties;
  defaultValue?: string;
  // onChange, value, variant, ............ тут повторяются поля, но они будут других типов
}

/**
 * Основной интерфейс пропсов, тут значения, которые есть вообще у всех инпутов в системе
 */
interface BaseInputProps<T extends FieldValues> {
  control: Control<T>;
  name: Path<T>;
  label: string;
  rules?: Omit<
    RegisterOptions<T, Path<T>>,
    'valueAsNumber' | 'valueAsDate' | 'setValueAs' | 'disabled'
  >; // Опциональные правила валидации
  margin?: 'dense' | 'normal' | 'none' | undefined;
}

export default function InputSelect<T extends FieldValues>({
  control,
  name,
  label,
  rules,
  style,
  margin,
  items,
  defaultValue,
}: InputSelectProps<T>) {

  return (
    <FormControl style={style}>
      <InputLabel id="level-label">{label}</InputLabel>
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState }) => (
          <>
            <Select error={!!fieldState.error} defaultValue={defaultValue} label={label} labelId="level-label" {...field}>
              {items.map((item) => (
                <MenuItem key={item.key} value={item.key}>
                  {item.value}
                </MenuItem>
              ))}
            </Select>
          </>
        )}
      />
      {/* <FormHelperText error={true}>
        {fieldState.error ? fieldState.error.message : 'sdf'}
      </FormHelperText> */}
    </FormControl>
  );
}
