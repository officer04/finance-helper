import { FC, useEffect, useState } from 'react';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import LoadingButton from '@mui/lab/LoadingButton';
import { useAppDispatch, useAppSelector } from '../../redux/hooks';
import { useNavigate } from 'react-router-dom';
import InputText from './input-text';
import { Autocomplete, Paper, styled, TextField } from '@mui/material';
import { FormInputCreateExpenseItem } from '../../types/ui/form-create-exprense-item/form-input-create-expense-item';
import { getExpenseItemType } from '../../redux/expense-item-type/expenseItemTypeSlice';
import { createExpenseItem } from '../../redux/expense-item/expenseItemSlice';

interface Props {}

const StyledPaper = styled(Paper)(({ theme }) => ({
  maxHeight: 300,
  overflowY: 'auto',
}));

export const FormCreateExpenseItem: FC<Props> = () => {
  const [isLoadingButton, setIsLoadingButton] = useState(false);
  const [color, setColor] = useState('')
  const { expenseItemType } = useAppSelector(({ expenseItemType }) => expenseItemType);

  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { t } = useTranslation();
  function getRandomHexColor(): string {
    const randomColor = Math.floor(Math.random() * 16777215).toString(16);
    return `#${randomColor.padStart(6, '0')}`;
  }

  const randomHexColor = getRandomHexColor();
  const {
    handleSubmit,
    control,
    register,
  } = useForm<FormInputCreateExpenseItem>({
    mode: 'onSubmit',
    defaultValues: { name: '', color: randomHexColor, expenseItemTypeCode: '' },
  });

  useEffect(() => {
    dispatch(getExpenseItemType());
  }, []);

  const onSubmit: SubmitHandler<FormInputCreateExpenseItem> = (data) => {
    setIsLoadingButton(true);
    console.log(data);
    const body = {
      name: data.name,
      color: data.color,
      expenseItemTypeCode: data.expenseItemTypeCode,
    };
    dispatch(createExpenseItem(body))
      .unwrap()
      .then((res) => {})
      .catch(() => {})
      .finally(() => setIsLoadingButton(false));
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="flex flex-col items-center justify-center gap-2"
    >
      <InputText
        control={control}
        name="name"
        label={t('inputNameExpenseItem')}
        rules={{
          required: t('inputRequiredFields'),
        }}
        style={{ width: '300px' }}
        margin="dense"
      />
      <div className="w-[300px] p-3 border-solid border-2 rounded-md flex items-center">
        <input
          type="color"
          // value={color}
          // onChange={handleColorChange}
          {...register('color')}
          className="w-[30px] h-[30px]"
        />
        <input
          type="text"
          // value={color}
          // onChange={handleColorChange}
          {...register('color')}
          className="w-[230px] outline-none  text-base"
          style={{ marginLeft: '10px' }}
        />
      </div>
      <Controller
        name="expenseItemTypeCode"
        control={control}
        rules={{
          required: t('inputRequiredFields'),
        }}
        render={({ field: { onChange, value }, fieldState }) => (
          <Autocomplete
            disablePortal
            sx={{ width: 300 }}
            options={expenseItemType}
            getOptionLabel={(option) => option.value}
            PaperComponent={StyledPaper}
            onChange={(event, newValue) => {
              onChange(newValue ? newValue.code : null);
            }}
            renderInput={(params) => (
              <TextField  
                {...params}
                label={t('inputExpenseItemTypeCodeExpenseItem')}
                error={!!fieldState.error}
                helperText={fieldState.error ? fieldState.error.message : null}
              />
            )}
            value={expenseItemType.find((option) => option.code === value)}
          />
        )}
      />
      <div className="text-center">
        <LoadingButton
          loading={isLoadingButton}
          variant="outlined"
          style={{ width: '300px' }}
          type="submit"
          size="large"
        >
          {t('buttonCreate')}
        </LoadingButton>
      </div>
    </form>
  );
};
