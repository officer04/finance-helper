import React, { FC, useState } from 'react';
import { Controller, Control, FieldValues, RegisterOptions, Path } from 'react-hook-form';
import TextField from '@mui/material/TextField';

/**
 * Пропсы для TextField
 */
interface InputTextProps<T extends FieldValues> extends BaseInputProps<T> {
  defaultValue?: string;
  style?: React.CSSProperties;
  // onChange, onInput, value, variant, ............
}

/**
 * Основной интерфейс пропсов, тут значения, которые есть вообще у всех инпутов в системе
 */
interface BaseInputProps<T extends FieldValues> {
  control: Control<T>;
  name: Path<T>;
  label: string;
  rules?: Omit<
    RegisterOptions<T, Path<T>>,
    'valueAsNumber' | 'valueAsDate' | 'setValueAs' | 'disabled'
  >; // Опциональные правила валидации
  margin?: 'dense' | 'normal' | 'none' | undefined;
}

export default function InputText<T extends FieldValues>({
  control,
  name,
  label,
  rules,
  style,
  margin,
  defaultValue,
}: InputTextProps<T>) {
  return (
    <Controller
      name={name}
      control={control}
      rules={rules}
      render={({ field, fieldState }) => (
        <TextField
          style={style}
          {...field}
          defaultValue={defaultValue}
          label={label}
          error={!!fieldState.error}
          helperText={fieldState.error ? fieldState.error.message : ''}
          variant="outlined"
          margin={margin}
        />
      )}
    />
  );
}
