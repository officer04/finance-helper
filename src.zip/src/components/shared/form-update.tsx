import React, { FC, useEffect, useState } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import LoadingButton from '@mui/lab/LoadingButton';

import { useAppDispatch, useAppSelector } from '../../redux/hooks';
import { getUserMe, registerUser, updateUserMe } from '../../redux/user/userSlice';
import { RegexConstants } from '../../lib/constants';
import { FormInputUpdate } from '../../types/ui/form-update/form-input-update';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { User } from '../../types/ui/form-update/user';
import { getSupportedLanguages } from '../../redux/supported-languages/supportedLanguagesSlice';
import InputText from './input-text';
import InputSelect from './input-select';

interface Props {
  setOpenSnackbar?: (str: boolean) => void;
}

export const FormUpdate: FC<Props> = ({ setOpenSnackbar }) => {
  const [isLoadingButton, setIsLoadingButton] = useState(false);
  const [select, setSelect] = useState("")
  const { supportedLanguages } = useAppSelector(({ supportedLanguages }) => supportedLanguages);
  const dispatch = useAppDispatch();
  const { t, i18n } = useTranslation();
  const {
    handleSubmit,
    control,
    setValue,
    formState: { errors, isValid },
  } = useForm<FormInputUpdate>({
    mode: 'onChange',
  });

  useEffect(() => {
    dispatch(getUserMe())
      .unwrap()
      .then((res) => {
        setValue('firstName', res.firstName);
        setValue('lastName', res.lastName);
        setValue('email', res.email);
        setValue('preferredLocalization', res.preferredLocalizationCode);
        setSelect(res.preferredLocalizationCode)
      });
    dispatch(getSupportedLanguages());
  }, []);

  const onSubmit: SubmitHandler<FormInputUpdate> = (data) => {
    console.log(data);
    setIsLoadingButton(true);
    const body = {
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      preferredLocalization: data.preferredLocalization,
    };
    dispatch(updateUserMe(body))
      .unwrap()
      .then((res) => {
        localStorage.setItem('bearerToken', res.bearerToken);
        i18n.changeLanguage(data.preferredLocalization);
        localStorage.setItem('selectedLanguage', data.preferredLocalization);
      })
      .catch(() => {
        // setOpenSnackbar(true);
      })
      .finally(() => setIsLoadingButton(false));
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)} className="mb-3 text-center">
      <InputText
        control={control}
        name="firstName"
        label={t('inputFirstName')}
        rules={{
          required: t('inputRequiredFields'),
          minLength: {
            value: 2,
            message: t('inputErrorFirstName'),
          },
          maxLength: {
            value: 32,
            message: t('inputErrorFirstName'),
          },
        }}
        style={{ width: '300px' }}
        margin="dense"
        defaultValue='Имя'
      />
      <InputText
        control={control}
        name="lastName"
        label={t('inputFirstName')}
        rules={{
          required: t('inputRequiredFields'),
          minLength: {
            value: 2,
            message: t('inputErrorLastName'),
          },
          maxLength: {
            value: 32,
            message: t('inputErrorLastName'),
          },
        }}
        style={{ width: '300px' }}
        margin="dense"
        defaultValue="Фамилия"
      />
      <InputText
        control={control}
        name="email"
        label={t('inputEmailUser')}
        rules={{
          required: t('inputRequiredFields'),
          pattern: {
            value: RegexConstants.EMAIL,
            message: t('inputErrorEmail'),
          },
        }}
        style={{ width: '300px' }}
        margin="dense"
        defaultValue="Почта"
      />
      <InputSelect
        control={control}
        name="preferredLocalization"
        label={t('inputSupportedLanguages')}
        rules={{ required: t('inputRequiredFields') }}
        items={supportedLanguages.map((lang) => {
          return { key: lang.code, value: lang.value };
        })}
        style={{ width: '300px', marginBottom: '10px', marginTop: '5px' }}
        defaultValue={select}
      />

      <div className="text-center">
        <LoadingButton
          loading={isLoadingButton}
          variant="outlined"
          disabled={!isValid}
          style={{ width: '300px' }}
          type="submit"
          size="large"
        >
          {t('buttonUpdate')}
        </LoadingButton>
      </div>
    </form>
  );
};
