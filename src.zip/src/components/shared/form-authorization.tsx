import React, { FC, useState } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import FormHelperText from '@mui/material/FormHelperText';
import LoadingButton from '@mui/lab/LoadingButton';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import Visibility from '@mui/icons-material/Visibility';

import { useAppDispatch } from '../../redux/hooks';
import { authorizationUser } from '../../redux/user/userSlice';
import { ApplicationRoutes, RegexConstants } from '../../lib/constants';
import { FormInputAuthorization } from '../../types/ui/form-login/form-input-authorization';
import { useNavigate } from 'react-router-dom';
import InputText from './input-text';
import InputPassword from './input-password';

interface Props {
  setOpenSnackbar: (str: boolean) => void;
}

export const FormAuthorization: FC<Props> = ({ setOpenSnackbar }) => {
  const [isLoadingButton, setIsLoadingButton] = useState(false);

  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const {
    handleSubmit,
    control,
    formState: { isValid },
  } = useForm<FormInputAuthorization>({ mode: 'onChange' });

  const onSubmit: SubmitHandler<FormInputAuthorization> = (data) => {
    setIsLoadingButton(true);
    const body = {
      email: data.email,
      password: data.password,
    };
    dispatch(authorizationUser(body))
      .unwrap()
      .then((res) => {
        localStorage.setItem('bearerToken', res.bearerToken);
        navigate(ApplicationRoutes.PROFILE);
      })
      .catch(() => {
        setOpenSnackbar(true);
      })
      .finally(() => setIsLoadingButton(false));
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)} className="mb-3 text-center">
      <InputText
        control={control}
        name="email"
        label={t('inputEmailUser')}
        rules={{
          required: t('inputErrorEmail'),
          pattern: {
            value: RegexConstants.EMAIL,
            message: t('inputErrorEmail'),
          },
        }}
        style={{ width: '300px' }}
        margin="dense"
      />
      <InputPassword
        control={control}
        name="password"
        label={t('inputPasswordUser')}
        rules={{
          required: t('inputRequiredFields'),
          pattern: {
            value: RegexConstants.PASSWORD,
            message: t('inputErrorPassword'),
          },
        }}
        style={{ width: '300px' }}
        margin="dense"
      />
      <div className="text-center">
        <LoadingButton
          loading={isLoadingButton}
          variant="outlined"
          disabled={!isValid}
          style={{ width: '300px' }}
          type="submit"
          size="large"
        >
          {t('buttonAuthorization')}
        </LoadingButton>
      </div>
    </form>
  );
};
