export interface IFormInputs {
    category: string;
}