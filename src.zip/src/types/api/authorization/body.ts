export interface AuthorizationUserBody {
  email: string;
  password: string;
}
