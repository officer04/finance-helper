export interface AuthorizationUserResponse {
  bearerToken: string;
}
