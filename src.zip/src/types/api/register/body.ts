export interface RegisterUserBody {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
}
