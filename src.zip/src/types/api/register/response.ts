export interface RegisterUserResponse {
  bearerToken: string;
  userId: string;
}
