export interface UserMeResponse {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  preferredLocalizationCode: string
}
