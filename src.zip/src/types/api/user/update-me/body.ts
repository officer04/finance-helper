export interface UpdateUserMeBody {
  email: string;
  firstName: string;
  lastName: string;
  preferredLocalization: string;
}
