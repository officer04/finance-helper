export interface UpdateUserMeBody {
  email: string;
  firstName: string;
  lastName: string;
  preferredLocalizationCode: string;
}
