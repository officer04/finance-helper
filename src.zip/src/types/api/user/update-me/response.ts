export interface UpdateUserMeResponse {
  bearerToken: string
}