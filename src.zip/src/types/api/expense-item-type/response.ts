import { ExpenseItemType } from "../../redux/expense-item-type/expense-item-type";

export interface ExpenseItemTypeResponse {
  items: ExpenseItemType[]
}