import { Item } from './item';

export interface GetExpenseItemResponse {
  items: Item[];
}
