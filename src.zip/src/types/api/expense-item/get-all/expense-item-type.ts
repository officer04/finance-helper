export interface ExpenseItemType {
  code: string;
  name: string;
}
