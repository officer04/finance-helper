export interface CreateExpenseItemResponse {
  id: number;
}