export interface CreateExpenseItemBody {
  name: string;
  color: string;
  expenseItemTypeCode: string
}