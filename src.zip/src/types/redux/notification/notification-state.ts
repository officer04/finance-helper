import { Notification } from "./notification";

export interface NotificationState {
  notification: Notification;
}