export type Notification = {
  text: string;
};

