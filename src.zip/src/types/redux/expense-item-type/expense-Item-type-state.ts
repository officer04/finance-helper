import { ExpenseItemType } from "./expense-item-type";

export interface ExpenseItemTypeState {
  expenseItemType: ExpenseItemType[]
}
