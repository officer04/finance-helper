export interface ExpenseItemType {
  code: string,
  value: string
}