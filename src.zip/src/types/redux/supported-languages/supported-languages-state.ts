import { LanguageBody, SupportedLanguageResponse } from "../../api/supported-languages/response";

export interface SupportedLanguagesState {
  supportedLanguages: LanguageBody[]
}