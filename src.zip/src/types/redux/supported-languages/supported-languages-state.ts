import { LanguageBody } from "../../api/supported-languages/response";

export interface SupportedLanguagesState {
  supportedLanguages: LanguageBody[]
}