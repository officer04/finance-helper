export interface UserState {
  isAuth: boolean;
}