export type LoadStatus = 'loading' | 'success' | 'error';
