export interface FormInputAuthorization {
  email: string;
  password: string;
}
