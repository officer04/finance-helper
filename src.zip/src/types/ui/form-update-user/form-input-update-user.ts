export interface FormInputUpdateUser {
  firstName: string;
  lastName: string;
  email: string;
  preferredLocalization: string;
}
