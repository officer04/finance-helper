export interface FormInputCreateExpenseItem {
  name: string;
  color: string;
  expenseItemTypeCode: string

}
