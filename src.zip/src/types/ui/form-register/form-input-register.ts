export interface FormInputRegister {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  repeatPassword: string;
}
