export interface SelectItem {
  key: string;
  value: string;
}