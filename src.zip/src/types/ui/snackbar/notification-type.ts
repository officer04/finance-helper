export enum NotificationType {
  InfoError = 'error',
  InfoSuccess = 'success',
}
